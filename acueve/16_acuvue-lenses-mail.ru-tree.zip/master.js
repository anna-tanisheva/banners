var timeline = new TimelineMax({repeat: -1, yoyo: false});

var background = document.getElementById("background"),
    text1 = document.getElementById("text-1"),
    text2 = document.getElementById("text-2"),
    text3 = document.getElementById("text-3"),
    table = document.getElementById("table"),
    logo = document.getElementById("logo"),
    logoText = document.getElementById("logo-text"),
    safe  = document.getElementById("safe");


    timeline.to(background, 0.5, {opacity: 1})
            .from(text1, 0.5, {opacity: 0})
            .to(text1, 0.5, {opacity: 0}, '+=2')
            .from(text2, 0.5, {opacity: 0})
            .from(table, 1, {y: 150}, '-=0.5')
            .to(text2, 0.5, {opacity: 0}, '+=2')
            .from(text3, 0.5, {opacity: 0})
            .to(text3, 0.5, {opacity: 0}, '+=2')
            .to([background, table], 0.5, {opacity: 0})
            .from(logo, 0.5, {scale: 0}, '-=0.5')
            .from(logoText, 0.5, {opacity: 0}, '-=0.5')
            .from(safe, 0.5, {opacity: 0})
            .to([logo, logoText, safe], 0.5, {opacity: 0}, '+=2');
